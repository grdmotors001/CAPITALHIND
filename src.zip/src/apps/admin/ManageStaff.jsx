import { useEffect, useState } from 'react';
import { createStaff, deleteStaff, listStaff, updateStaffContact, resetPassword } from './api';

const emptyForm = { username: '', password: '', role: 'staff', contact_mobile: '', email: '' };

const ROLE_LABELS = { staff: 'Staff', cashier: 'Cashier', admin: 'Admin' };

export default function ManageStaff() {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  async function load() {
    setLoading(true);
    setError('');
    try {
      const data = await listStaff();
      setUsers(data.users || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  function updateForm(key, value) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true); setError(''); setMessage('');
    try {
      const data = await createStaff(form);
      setMessage(data.message || 'Account created successfully.');
      setForm(emptyForm);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  function beginEdit(user) {
    setEditing({ ...user });
    setMessage(''); setError('');
  }

  async function saveEdit(e) {
    e.preventDefault();
    setSaving(true); setError(''); setMessage('');
    try {
      const data = await updateStaffContact({
        id: editing.id,
        role: editing.role,
        source: editing.source,
        contact_mobile: editing.contact_mobile || '',
        email: editing.email || '',
      });
      setMessage(data.message || 'Contact details updated.');
      setEditing(null);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function resetStaffPassword(user) {
    const next = window.prompt(`Set new password for ${user.username} (minimum 8 characters):`);
    if (next === null) return;
    if (next.length < 8) { setError('Password must be at least 8 characters.'); return; }
    const confirm = window.prompt('Re-enter the new password:');
    if (confirm !== next) { setError('Passwords do not match.'); return; }
    setError(''); setMessage('');
    try { const data = await resetPassword({ id: user.id, table: user.source === 'users' ? 'users' : 'staff_accounts', new_password: next }); setMessage(data.message || 'Password reset successfully.'); }
    catch (err) { setError(err.message); }
  }

  async function remove(user) {
    if (!window.confirm(`Remove account "${user.username}"?`)) return;
    setError(''); setMessage('');
    try {
      const data = await deleteStaff(user);
      setMessage(data.message || 'Account removed.');
      await load();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="admin-page">
      <div className="admin-page-head">
        <div>
          <div className="admin-eyebrow">ADMINISTRATION</div>
          <h1>Manage Staff</h1>
          <p>Create staff/admin accounts and manage OTP & Google-login contact details.</p>
        </div>
        <div className="admin-count">{users.length} account{users.length === 1 ? '' : 's'}</div>
      </div>

      {message && <div className="admin-alert success">✓ {message}</div>}
      {error && <div className="admin-alert error">⚠ {error}</div>}

      <section className="admin-card staff-list-card">
        <div className="admin-card-title">
          <div><h2>Staff & Admin Accounts</h2><span>Existing accounts</span></div>
          <button className="admin-btn secondary" onClick={load} disabled={loading}>↻ Refresh</button>
        </div>
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead><tr><th>Username</th><th>Role</th><th>Mobile / Email</th><th>Added</th><th>Actions</th></tr></thead>
            <tbody>
              {loading ? <tr><td colSpan="5" className="empty-cell">Loading accounts…</td></tr> : users.length === 0 ? <tr><td colSpan="5" className="empty-cell">No staff accounts found.</td></tr> : users.map((user) => (
                <tr key={`${user.source}-${user.id}`}>
                  <td><strong>{user.username}</strong></td>
                  <td><span className={`role-pill ${user.role}`}>{ROLE_LABELS[user.role] || user.role}</span></td>
                  <td className="contact-text">
                    <div>{user.contact_mobile || <span className="muted">No mobile</span>}</div>
                    <div>{user.email || <span className="muted">No email</span>}</div>
                  </td>
                  <td>{user.created_at ? String(user.created_at).slice(0, 10) : '—'}</td>
                  <td className="actions-cell">
                    <button className="admin-btn small secondary" onClick={() => beginEdit(user)}>Edit contact</button>
                    <button className="admin-btn small secondary" onClick={() => resetStaffPassword(user)}>Reset Password</button>{user.is_current ? <span className="you-tag">You</span> : <button className="admin-btn small danger" onClick={() => remove(user)}>Remove</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {editing && (
          <form className="inline-edit" onSubmit={saveEdit}>
            <div><label>Mobile (OTP login)</label><input maxLength="10" value={editing.contact_mobile || ''} onChange={(e) => setEditing({ ...editing, contact_mobile: e.target.value.replace(/\D/g, '').slice(0, 10) })} placeholder="98xxxxxxxx" /></div>
            <div><label>Email (Google login)</label><input type="email" value={editing.email || ''} onChange={(e) => setEditing({ ...editing, email: e.target.value })} placeholder="name@gmail.com" /></div>
            <div className="edit-actions"><button className="admin-btn" disabled={saving}>{saving ? 'Saving…' : 'Save changes'}</button><button type="button" className="admin-btn secondary" onClick={() => setEditing(null)}>Cancel</button></div>
          </form>
        )}
      </section>

      <section className="admin-card create-card">
        <div className="admin-card-title"><div><h2>Add Staff / Admin Account</h2><span>New login credentials</span></div></div>
        <form className="staff-form" onSubmit={handleCreate}>
          <div className="form-grid">
            <div><label>Username</label><input value={form.username} onChange={(e) => updateForm('username', e.target.value)} required autoComplete="off" /></div>
            <div><label>Password <span>(minimum 8 characters)</span></label><input type="password" value={form.password} onChange={(e) => updateForm('password', e.target.value)} minLength="8" required autoComplete="new-password" /></div>
            <div><label>Role</label><select value={form.role} onChange={(e) => updateForm('role', e.target.value)}><option value="staff">Staff — view records & verify/reject UPI payments</option><option value="cashier">Cashier — receive & track FE cash</option><option value="admin">Admin — full access, manage accounts</option></select></div>
            <div><label>Mobile {form.role === 'admin' ? <span>(login id, 10 digits)</span> : <span>(optional — OTP login)</span>}</label><input value={form.contact_mobile} onChange={(e) => updateForm('contact_mobile', e.target.value.replace(/\D/g, '').slice(0, 10))} maxLength="10" placeholder="98xxxxxxxx" required={form.role === 'admin' && !form.email} /></div>
            <div className="full"><label>Email {form.role === 'admin' ? <span>(required if mobile is blank)</span> : <span>(optional — Google login)</span>}</label><input type="email" value={form.email} onChange={(e) => updateForm('email', e.target.value)} placeholder="name@gmail.com" required={form.role === 'admin' && !form.contact_mobile} /></div>
          </div>
          <button className="admin-btn" disabled={saving}>{saving ? 'Creating…' : '+ Create account'}</button>
        </form>
      </section>
    </div>
  );
}
